# RISE-Agent: Physics Paper Figure Reproduction

A unified tool for converting physics papers to Markdown and reproducing their figures programmatically.

## Overview

RISE-Agent combines PDF-to-Markdown conversion with scientific figure reproduction in a streamlined 6-phase workflow:

1. **Phase 0:** Convert PDF to Markdown using Qwen VLM
2. **Phase 1:** Comprehend the paper and identify figures
3. **Phase 2:** Set up the development environment
4. **Phase 3:** Plan the reproduction approach
5. **Phase 4:** Implement Python scripts to reproduce figures
6. **Phase 5:** Document the work in LaTeX

## TODO List: (IMPORTANT, the list will be updated frequently)

1. Ensure the correctness of citations when generating the technical document. For High Energy Physics papers, it can be easily done by writing subagent to query INSPIRE-HEP database.
2. Add IdeaSearch for recursive computation optimization.
3. Figure out how to put this code to massive production use for, say, 100 papers.
4. Revise the agent framework to save money, improve quality and speed.
5. Test on Chinese models.
6. Test on different papers from different fields.

## Quick Start

### 1. Setup (one-time)

```bash
# Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or: venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Configure API key
cp .env.example .env
# Edit .env and add your DASHSCOPE_API_KEY
```

### 2. Reproduce a Paper

```bash
# Place your PDF in input/
cp /path/to/paper.pdf input/

# Start Claude Code
claude
```

Then just ask:
> "Reproduce the figures from the paper in input/"

Claude will automatically:
1. Convert the PDF to Markdown (Phase 0)
2. Analyze the paper and identify figures (Phase 1)
3. Set up the environment (Phase 2)
4. Plan the reproduction approach (Phase 3)
5. Write Python scripts in `reproduction/` (Phase 4)
6. Generate plots in `plots/` (Phase 4)
7. Create LaTeX documentation in `technical_docs/` (Phase 5)

## Project Structure

```
rise-agent/
├── input/           # Place input PDFs here
├── markdown/        # Converted markdown files
├── reproduction/    # Python scripts for figure reproduction
├── plots/           # Generated figures
├── technical_docs/  # LaTeX documentation
└── subagents/       # Specialized agent packages
    └── pdf2markdown/    # PDF conversion agent
```

## Requirements

- Python 3.10+
- DashScope API key (for Qwen VLM)

## Features

### PDF Conversion
- High-quality PDF to image rendering
- Accurate LaTeX equation transcription
- Structured figure information extraction
- Streaming output support
- Reasoning mode for complex documents

### Figure Reproduction
- NumPy/SciPy for numerical computation
- Matplotlib for publication-quality plots
- SymPy for symbolic mathematics
- LaTeX documentation generation

## Usage Examples

```bash
# Convert entire PDF
python convert_pdf.py input/paper.pdf

# Convert specific pages
python convert_pdf.py input/paper.pdf --pages 1-10

# Enable reasoning mode for complex math
python convert_pdf.py input/paper.pdf --thinking

# Custom output location
python convert_pdf.py input/paper.pdf -o markdown/custom_name.md
```

## API Configuration

This API is used for PDF to Markdown conversion with Qwen VLM, which is much cheaper than using GPT5.
Get your DashScope API key from: https://dashscope.console.aliyun.com/

Add to `.env`:
```
DASHSCOPE_API_KEY=your_key_here
```

We have also published a public use API in Feishu Rise-AGI 公用账号.

## License

MIT

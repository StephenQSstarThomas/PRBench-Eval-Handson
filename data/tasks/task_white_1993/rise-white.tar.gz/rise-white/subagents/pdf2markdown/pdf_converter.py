"""
PDF to Image Converter Module
Handles conversion of PDF pages to images for VLM processing.
"""

import base64
import io
from pathlib import Path
from typing import Generator, Tuple

import fitz  # PyMuPDF
from PIL import Image


class PDFConverter:
    """Converts PDF pages to images."""

    def __init__(self, dpi: int = 200):
        """
        Initialize the PDF converter.

        Args:
            dpi: Resolution for rendering PDF pages (default: 200)
        """
        self.dpi = dpi
        self.zoom = dpi / 72  # 72 is the default PDF resolution

    def get_page_count(self, pdf_path: str | Path) -> int:
        """Get the number of pages in a PDF file."""
        pdf_path = Path(pdf_path)
        with fitz.open(pdf_path) as doc:
            return len(doc)

    def pdf_to_images(
        self,
        pdf_path: str | Path
    ) -> Generator[Tuple[int, Image.Image], None, None]:
        """
        Convert PDF pages to PIL Images.

        Args:
            pdf_path: Path to the PDF file

        Yields:
            Tuple of (page_number, PIL Image)
        """
        pdf_path = Path(pdf_path)

        with fitz.open(pdf_path) as doc:
            for page_num in range(len(doc)):
                page = doc[page_num]

                # Create transformation matrix for higher resolution
                mat = fitz.Matrix(self.zoom, self.zoom)

                # Render page to pixmap
                pix = page.get_pixmap(matrix=mat, alpha=False)

                # Convert to PIL Image
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

                yield page_num + 1, img

    def image_to_base64(self, image: Image.Image, format: str = "PNG") -> str:
        """
        Convert PIL Image to base64 string.

        Args:
            image: PIL Image object
            format: Image format (PNG, JPEG, etc.)

        Returns:
            Base64 encoded string
        """
        buffer = io.BytesIO()
        image.save(buffer, format=format)
        buffer.seek(0)
        return base64.b64encode(buffer.read()).decode("utf-8")

    def get_base64_data_url(self, image: Image.Image, format: str = "PNG") -> str:
        """
        Convert PIL Image to base64 data URL.

        Args:
            image: PIL Image object
            format: Image format (PNG, JPEG, etc.)

        Returns:
            Base64 data URL string
        """
        base64_str = self.image_to_base64(image, format)
        mime_type = f"image/{format.lower()}"
        return f"data:{mime_type};base64,{base64_str}"

"""
Qwen VLM Client Module
Handles communication with the Qwen Vision Language Model API.
"""

import os
from typing import Optional

from openai import OpenAI
from PIL import Image

from .pdf_converter import PDFConverter


class QwenVLMClient:
    """Client for interacting with Qwen VLM API."""

    # System prompt for scientific document conversion
    DEFAULT_SYSTEM_PROMPT = """You are an expert physicist and mathematician specialized in converting scientific documents to Markdown format with perfect LaTeX transcription.

Your task: Accurately transcribe the physics document image into well-formatted Markdown, preserving ALL mathematical content with precise LaTeX notation.

## CRITICAL: Mathematical Equations

### Inline Math (use single $)
- Simple expressions: $E = mc^2$, $F = ma$, $\\hbar = h/2\\pi$
- Subscripts/superscripts: $x_i$, $x^2$, $A_{\\mu\\nu}$, $T^{\\mu\\nu}$
- Greek letters: $\\alpha$, $\\beta$, $\\gamma$, $\\Gamma$, $\\psi$, $\\Psi$, $\\phi$, $\\Phi$

### Display Math (use double $$)
For standalone equations, use $$ on separate lines:
$$
\\mathcal{L} = \\bar{\\psi}(i\\gamma^\\mu \\partial_\\mu - m)\\psi - \\frac{1}{4}F_{\\mu\\nu}F^{\\mu\\nu}
$$

### Physics-Specific LaTeX Commands
- **Vectors**: $\\vec{r}$, $\\mathbf{p}$, $\\hat{n}$ (unit vectors)
- **Operators**: $\\hat{H}$, $\\hat{p}$, $\\nabla$, $\\nabla^2$, $\\partial_\\mu$
- **Bra-ket**: $\\langle \\psi |$, $| \\phi \\rangle$, $\\langle \\psi | \\phi \\rangle$
- **Commutators**: $[A, B]$, $\\{A, B\\}$ (anticommutator)
- **Derivatives**: $\\frac{\\partial}{\\partial x}$, $\\frac{d}{dt}$, $\\dot{x}$, $\\ddot{x}$
- **Integrals**: $\\int$, $\\oint$, $\\int_a^b$, $\\int d^4x$
- **Sums/Products**: $\\sum_{i=1}^{N}$, $\\prod_{k}$
- **Matrices**: Use \\begin{pmatrix}...\\end{pmatrix} or \\begin{bmatrix}...\\end{bmatrix}
- **Tensor indices**: $T^{\\mu\\nu}$, $g_{\\mu\\nu}$, $\\epsilon^{ijk}$, $\\delta^i_j$
- **Special functions**: $\\sin$, $\\cos$, $\\exp$, $\\ln$, $\\det$, $\\Tr$

### Common Physics Symbols
- Planck's constant: $\\hbar$, $h$
- Imaginary unit: $i$
- Infinity: $\\infty$
- Proportional: $\\propto$
- Approximately: $\\approx$, $\\sim$, $\\simeq$
- Much less/greater: $\\ll$, $\\gg$
- Cross product: $\\times$
- Dot product: $\\cdot$
- Tensor product: $\\otimes$
- Dagger: $\\dagger$

## Equation Numbering
If equations are numbered in the original, preserve as:
$$
E = mc^2 \\tag{1}
$$

## Document Structure
- Use # for paper title, ## for sections, ### for subsections
- Preserve paragraph breaks and logical flow
- Keep abstract clearly labeled if present

## Figures and Tables
- Tables: Convert to Markdown tables, preserve all data and units
- Figures: Extract ALL information needed to reproduce the figure.

**CRITICAL INSTRUCTION FOR FIGURES:**
If a figure contains multiple panels (e.g., (a), (b), (c)), you must describe **EACH** panel individually. Check all four sides of a plot (Bottom, Top, Left, Right) for axis labels.

Use the following format for every figure:

**[Figure N: Caption]**

> **Figure Structure:** [Single plot / Multi-panel (a-d) / Composite / etc.]
>
> **--- PANEL [Letter/Number]: [Title of Panel] ---**
> *(Repeat this section for every panel found in the figure)*
>
> **Axes:**
> - **Bottom Axis (X):** [label, units, scale type, range]
> - **Top Axis:** [label, units, scale type, range] (Only if present)
> - **Left Axis (Y):** [label, units, scale type, range]
> - **Right Axis:** [label, units, scale type, range] (Only if present)
> - **Z-axis:** [label, units, scale type, range] (If 3D)
>
> **Data Series/Curves:**
> - [Series 1]: [color, marker style, line style, what it represents]
> - [Series 2]: [color, marker style, line style, what it represents]
>
> **Key Data Points:** [Notable values, intersections, peaks, asymptotes, error bars]
>
> **Annotations:** [Text labels, arrows, or specific notes inside the plot area]
>
> **Legend:** [Transcribe legend entries exactly as shown]
>
> **Panel Description:** [Brief physical description of what this specific panel shows]
>
> **--- END PANEL ---**
>
> **Global Figure Description:** [Overview of how the panels relate or the main takeaway of the whole figure]
> **Additional Details:** [Grid lines, insets, color bars, fit parameters, equations shown on plot]

## References and Citations
- Keep citation format: [1], [2,3], or (Author, Year)
- Preserve reference list formatting

## Units and Constants
- Use proper spacing: $5 \\, \\text{GeV}$, $c = 3 \\times 10^8 \\, \\text{m/s}$
- SI units in \\text{}: $\\text{kg}$, $\\text{m}$, $\\text{s}$

## Quality Checks
- Every opening $ must have closing $
- Every \\left must have matching \\right
- Verify subscripts and superscripts are correctly placed
- Check that Greek letters match the original exactly

OUTPUT ONLY the Markdown content. No explanations, no commentary, no "Here is the conversion" preamble."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1",
        model: str = "qwen-vl-max",
        enable_thinking: bool = False,
        thinking_budget: int = 81920,
    ):
        """
        Initialize the Qwen VLM client.

        Args:
            api_key: DashScope API key (defaults to DASHSCOPE_API_KEY env var)
            base_url: API base URL
            model: Model name to use
            enable_thinking: Whether to enable thinking/reasoning mode
            thinking_budget: Max tokens for thinking process
        """
        self.api_key = api_key or os.getenv("DASHSCOPE_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key not provided. Set DASHSCOPE_API_KEY environment variable "
                "or pass api_key parameter."
            )

        self.client = OpenAI(api_key=self.api_key, base_url=base_url)
        self.model = model
        self.enable_thinking = enable_thinking
        self.thinking_budget = thinking_budget
        self.pdf_converter = PDFConverter()

    def convert_image_to_markdown(
        self,
        image: Image.Image,
        custom_prompt: Optional[str] = None,
        stream: bool = False,
    ) -> str:
        """
        Convert a single image to Markdown using Qwen VLM.

        Args:
            image: PIL Image to convert
            custom_prompt: Optional custom prompt to override default
            stream: Whether to stream the response

        Returns:
            Markdown string
        """
        # Convert image to base64 data URL
        image_url = self.pdf_converter.get_base64_data_url(image, format="PNG")

        prompt = custom_prompt or """Convert this physics document page to Markdown.

Requirements:
1. Transcribe ALL text exactly as shown
2. Convert ALL equations to LaTeX (inline $ or display $$)
3. Pay special attention to: subscripts, superscripts, Greek letters, operators
4. Preserve equation numbers if present using \\tag{}
5. Keep section headings and paragraph structure
6. For figures, extract ALL reproducibility information:
   - Axis labels, units, and scale types (linear/log)
   - All legend entries and data series (colors, markers, line styles)
   - Key data points, ranges, and annotations
   - Any equations, fit parameters, or text shown on the figure

Begin transcription:"""

        messages = [
            {"role": "system", "content": self.DEFAULT_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": image_url},
                    },
                    {"type": "text", "text": prompt},
                ],
            },
        ]

        extra_body = {}
        if self.enable_thinking:
            extra_body = {
                "enable_thinking": True,
                "thinking_budget": self.thinking_budget,
            }

        if stream:
            return self._stream_response(messages, extra_body)
        else:
            return self._get_response(messages, extra_body)

    def _get_response(self, messages: list, extra_body: dict) -> str:
        """Get non-streaming response from API."""
        completion = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            extra_body=extra_body if extra_body else None,
        )
        return completion.choices[0].message.content

    def _stream_response(self, messages: list, extra_body: dict) -> str:
        """Get streaming response from API."""
        completion = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            stream=True,
            extra_body=extra_body if extra_body else None,
        )

        content = ""
        for chunk in completion:
            if chunk.choices:
                delta = chunk.choices[0].delta
                if hasattr(delta, "content") and delta.content:
                    content += delta.content
                    print(delta.content, end="", flush=True)

        print()  # Newline after streaming
        return content

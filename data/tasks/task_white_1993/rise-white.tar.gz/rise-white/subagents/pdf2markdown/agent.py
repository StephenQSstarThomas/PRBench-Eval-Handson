"""
PDF to Markdown Conversion Agent
Main agent that orchestrates the PDF to Markdown conversion process.
"""

import os
from pathlib import Path
from typing import Callable, Optional

from tqdm import tqdm

from .pdf_converter import PDFConverter
from .vlm_client import QwenVLMClient


class PDF2MarkdownAgent:
    """Agent for converting PDF documents to Markdown using Qwen VLM."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "qwen-vl-max",
        dpi: int = 200,
        enable_thinking: bool = False,
        thinking_budget: int = 4096,
    ):
        """
        Initialize the PDF to Markdown conversion agent.

        Args:
            api_key: DashScope API key
            model: Qwen VLM model to use
            dpi: Resolution for PDF rendering
            enable_thinking: Enable reasoning mode for complex documents
            thinking_budget: Max tokens for thinking process
        """
        self.pdf_converter = PDFConverter(dpi=dpi)
        self.vlm_client = QwenVLMClient(
            api_key=api_key,
            model=model,
            enable_thinking=enable_thinking,
            thinking_budget=thinking_budget,
        )

    def convert_pdf(
        self,
        pdf_path: str | Path,
        output_path: Optional[str | Path] = None,
        page_range: Optional[tuple[int, int]] = None,
        stream: bool = False,
        progress_callback: Optional[Callable[[int, int], None]] = None,
        page_separator: str = "\n\n---\n\n",
    ) -> str:
        """
        Convert a PDF file to Markdown.

        Args:
            pdf_path: Path to the input PDF file
            output_path: Path to save the output Markdown file (optional)
            page_range: Tuple of (start_page, end_page) for partial conversion (1-indexed)
            stream: Whether to stream the API response
            progress_callback: Callback function(current_page, total_pages)
            page_separator: Separator between pages in the output

        Returns:
            Complete Markdown string
        """
        pdf_path = Path(pdf_path)
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF file not found: {pdf_path}")

        total_pages = self.pdf_converter.get_page_count(pdf_path)

        # Determine page range
        start_page = 1
        end_page = total_pages
        if page_range:
            start_page = max(1, page_range[0])
            end_page = min(total_pages, page_range[1])

        markdown_parts = []
        pages_to_process = end_page - start_page + 1

        print(f"Converting PDF: {pdf_path.name}")
        print(f"Total pages: {total_pages}, Processing pages {start_page}-{end_page}")

        # Process each page
        with tqdm(total=pages_to_process, desc="Converting pages") as pbar:
            for page_num, image in self.pdf_converter.pdf_to_images(pdf_path):
                # Skip pages outside the range
                if page_num < start_page or page_num > end_page:
                    continue

                # Update progress
                if progress_callback:
                    progress_callback(page_num - start_page + 1, pages_to_process)

                # Convert page to markdown
                print(f"\n--- Processing page {page_num} ---")
                page_markdown = self.vlm_client.convert_image_to_markdown(
                    image, stream=stream
                )

                # Add page header and content
                markdown_parts.append(f"<!-- Page {page_num} -->\n\n{page_markdown}")

                pbar.update(1)

        # Combine all pages
        full_markdown = page_separator.join(markdown_parts)

        # Add document header
        header = f"# {pdf_path.stem}\n\n"
        header += f"*Converted from: {pdf_path.name}*\n\n"
        header += "---\n\n"
        full_markdown = header + full_markdown

        # Save to file if output path provided
        if output_path:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(full_markdown, encoding="utf-8")
            print(f"\nMarkdown saved to: {output_path}")

        return full_markdown

    def convert_single_page(
        self,
        pdf_path: str | Path,
        page_number: int,
        stream: bool = False,
    ) -> str:
        """
        Convert a single page of a PDF to Markdown.

        Args:
            pdf_path: Path to the PDF file
            page_number: Page number to convert (1-indexed)
            stream: Whether to stream the response

        Returns:
            Markdown string for the page
        """
        pdf_path = Path(pdf_path)

        for page_num, image in self.pdf_converter.pdf_to_images(pdf_path):
            if page_num == page_number:
                return self.vlm_client.convert_image_to_markdown(image, stream=stream)

        raise ValueError(f"Page {page_number} not found in {pdf_path}")


def create_agent(
    api_key: Optional[str] = None,
    model: str = "qwen-vl-max",
    **kwargs
) -> PDF2MarkdownAgent:
    """
    Factory function to create a PDF2MarkdownAgent.

    Args:
        api_key: DashScope API key (uses env var if not provided)
        model: Model name to use
        **kwargs: Additional arguments passed to PDF2MarkdownAgent

    Returns:
        Configured PDF2MarkdownAgent instance
    """
    return PDF2MarkdownAgent(api_key=api_key, model=model, **kwargs)

"""
Figure 2 Reproduction: Density-Matrix Eigenvalues vs Eigenvalue Index

Reproduces Figure 2 from White, Phys. Rev. B 48, 10345 (1993), Section VII.

Figure Description (from paper):
    "Figure 2 shows the density-matrix eigenvalues w_alpha for a 32 site system
    for both open and periodic boundary conditions, and for both S=1/2 and S=1,
    targeting one state."

Plot Specifications:
    - X-axis: alpha (eigenvalue index), linear scale, range 0 to 50
    - Y-axis: w_alpha (density-matrix eigenvalues), log scale, 10^0 to 10^-7
    - System: L=32 sites

Data Series (4 curves with markers from paper):
    - Periodic, S=1:   open squares (□), solid line
    - Periodic, S=1/2: asterisks (*), solid line
    - Open, S=1:       filled inverted triangles (▼), solid line
    - Open, S=1/2:     filled triangles (▲), solid line

Annotations:
    - "L=32" in top right corner
"""

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.ticker import LogLocator

# Use LaTeX-style fonts for publication quality
plt.rcParams.update(
    {
        "text.usetex": False,  # Set True if LaTeX is available
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 12,
        "axes.labelsize": 14,
        "axes.titlesize": 14,
        "legend.fontsize": 11,
        "xtick.labelsize": 12,
        "ytick.labelsize": 12,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.linewidth": 1.0,
        "xtick.major.width": 1.0,
        "ytick.major.width": 1.0,
    }
)


def load_fig2_data(filepath="data/fig2.csv"):
    """Load computed density-matrix eigenvalues from CSV."""
    # Resolve path relative to project root
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_path = os.path.join(project_root, filepath)

    df = pd.read_csv(full_path)
    return df


def plot_fig2(df, output_path="data/fig2_plot.pdf"):
    """
    Create publication-quality reproduction of Figure 2.

    Follows exact specifications from the paper:
    - Logarithmic y-axis from 10^0 to 10^-7
    - Linear x-axis from 0 to 50
    - Specific marker styles for each curve
    """
    fig, ax = plt.subplots(figsize=(8, 6))

    # Extract data columns
    alpha = df["alpha"].values

    # Define plot styles matching the paper exactly
    # Paper specifies:
    #   - Periodic, S=1:   open squares
    #   - Periodic, S=1/2: asterisks
    #   - Open, S=1:       filled inverted triangles
    #   - Open, S=1/2:     filled triangles
    # Use small markers since we have one at every data point

    plot_configs = [
        {
            "key": "Periodic, S=1",
            "label": r"Periodic, $S=1$",
            "marker": "s",  # square
            "markerfacecolor": "none",  # open (unfilled)
            "markeredgecolor": "black",
            "color": "black",
            "markersize": 4,
        },
        {
            "key": "Periodic, S=1/2",
            "label": r"Periodic, $S=1/2$",
            "marker": "*",  # asterisk
            "markerfacecolor": "black",
            "markeredgecolor": "black",
            "color": "black",
            "markersize": 5,
        },
        {
            "key": "Open, S=1",
            "label": r"Open, $S=1$",
            "marker": "v",  # inverted triangle
            "markerfacecolor": "black",  # filled
            "markeredgecolor": "black",
            "color": "black",
            "markersize": 4,
        },
        {
            "key": "Open, S=1/2",
            "label": r"Open, $S=1/2$",
            "marker": "^",  # triangle
            "markerfacecolor": "black",  # filled
            "markeredgecolor": "black",
            "color": "black",
            "markersize": 4,
        },
    ]

    # Plot each curve with marker at every data point (small markers)
    for config in plot_configs:
        key = config["key"]
        w_alpha = df[key].values

        # Filter out NaN values and clip to x-axis range
        valid_mask = ~np.isnan(w_alpha) & (alpha <= 50)
        x = alpha[valid_mask]
        y = w_alpha[valid_mask]

        # Filter out zero or negative values for log scale
        positive_mask = y > 0
        x = x[positive_mask]
        y = y[positive_mask]

        ax.semilogy(
            x,
            y,
            linestyle="-",
            linewidth=0.8,
            marker=config["marker"],
            markerfacecolor=config["markerfacecolor"],
            markeredgecolor=config["markeredgecolor"],
            markeredgewidth=0.5,
            markersize=config["markersize"],
            color=config["color"],
            label=config["label"],
        )

    # Set axis limits matching the paper
    ax.set_xlim(0, 50)
    ax.set_ylim(1e-7, 1e0)

    # Axis labels with LaTeX formatting
    ax.set_xlabel(r"$\alpha$")
    ax.set_ylabel(r"$w_\alpha$")

    # Add "L=32" annotation in top right corner (paper style)
    ax.text(
        0.95,
        0.95,
        r"$L=32$",
        transform=ax.transAxes,
        fontsize=12,
        verticalalignment="top",
        horizontalalignment="right",
    )

    # Legend positioned to avoid data
    ax.legend(
        loc="lower left",
        frameon=True,
        framealpha=0.9,
        edgecolor="black",
    )

    # Grid for readability (subtle)
    ax.grid(True, which="major", linestyle="-", linewidth=0.5, alpha=0.3)
    ax.grid(True, which="minor", linestyle=":", linewidth=0.3, alpha=0.2)

    # Ensure minor ticks are visible on log scale
    ax.yaxis.set_minor_locator(
        LogLocator(
            base=10.0, subs=(0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9), numticks=100
        )
    )

    # Tight layout
    plt.tight_layout()

    # Save figure
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_output_path = os.path.join(project_root, output_path)

    # Ensure output directory exists
    os.makedirs(os.path.dirname(full_output_path), exist_ok=True)

    plt.savefig(full_output_path)
    print(f"Figure saved to: {full_output_path}")

    # Also save as PNG for quick viewing
    png_path = full_output_path.replace(".pdf", ".png")
    plt.savefig(png_path)
    print(f"PNG saved to: {png_path}")

    plt.close()

    return fig


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("FIGURE 2 REPRODUCTION")
    print("Reference: White, Phys. Rev. B 48, 10345 (1993), Section VII")
    print("=" * 70)

    # Load computed data
    print("\nLoading data from data/fig2.csv...")
    df = load_fig2_data()
    print(f"Loaded {len(df)} data points")

    # Create the plot
    print("\nGenerating Figure 2...")
    plot_fig2(df, output_path="plots/fig2_plot.pdf")

    print("\n" + "=" * 70)
    print("DONE")
    print("=" * 70)

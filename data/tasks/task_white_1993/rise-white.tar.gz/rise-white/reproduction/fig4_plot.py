"""
Figure 4 Reproduction: Relative Error vs Number of States Kept (S=1)

Reproduces Figure 4 from White, Phys. Rev. B 48, 10345 (1993), Section VII.

Figure Description (from paper):
    "Relative error in the ground state energy E for a 16 site S=1 system,
    as a function of the number of states kept m, for periodic and open
    boundary conditions."

Plot Specifications:
    - X-axis: m (number of states kept), linear scale, range 0 to 125
    - Y-axis: ΔE/|E| (relative error), log scale, 10^-1 to 10^-9
    - System: L=16 sites, S=1

Data Series (2 curves with markers from paper):
    - Periodic BCs: open squares (□), solid line
    - Open BCs:     filled circles (●), solid line

Annotations:
    - "S=1, L=16" in top right corner
"""

import os

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.ticker import LogLocator

# Use LaTeX-style fonts for publication quality
plt.rcParams.update(
    {
        "text.usetex": False,  # Set True if LaTeX is available
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 12,
        "axes.labelsize": 14,
        "axes.titlesize": 14,
        "legend.fontsize": 11,
        "xtick.labelsize": 12,
        "ytick.labelsize": 12,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.linewidth": 1.0,
        "xtick.major.width": 1.0,
        "ytick.major.width": 1.0,
    }
)


def load_fig4_data(filepath="data/fig4.csv"):
    """Load computed relative error data from CSV."""
    # Resolve path relative to project root
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_path = os.path.join(project_root, filepath)

    df = pd.read_csv(full_path)
    return df


def plot_fig4(df, output_path="data/fig4_plot.pdf"):
    """
    Create publication-quality reproduction of Figure 4.

    Follows exact specifications from the paper:
    - Logarithmic y-axis from 10^-1 to 10^-9
    - Linear x-axis from 0 to 125
    - Specific marker styles for each curve
    """
    fig, ax = plt.subplots(figsize=(8, 6))

    # Extract data columns
    m = df["m"].values
    error_open = df["Open BCs"].values
    error_periodic = df["Periodic BCs"].values

    # Define plot styles matching the paper exactly
    # Paper specifies:
    #   - Periodic BCs: open squares
    #   - Open BCs:     filled circles

    # Plot Periodic BCs (open squares)
    ax.semilogy(
        m,
        error_periodic,
        linestyle="-",
        linewidth=0.8,
        marker="s",
        markerfacecolor="none",
        markeredgecolor="black",
        markeredgewidth=0.8,
        markersize=6,
        color="black",
        label=r"Periodic BCs",
    )

    # Plot Open BCs (filled circles)
    ax.semilogy(
        m,
        error_open,
        linestyle="-",
        linewidth=0.8,
        marker="o",
        markerfacecolor="black",
        markeredgecolor="black",
        markeredgewidth=0.5,
        markersize=5,
        color="black",
        label=r"Open BCs",
    )

    # Set axis limits matching the paper
    ax.set_xlim(0, 125)
    ax.set_ylim(1e-9, 1e-1)

    # Axis labels with LaTeX formatting
    ax.set_xlabel(r"$m$")
    ax.set_ylabel(r"$\Delta E / |E|$")

    # Add "S=1, L=16" annotation in top right corner (paper style)
    ax.text(
        0.95,
        0.95,
        r"$S=1$, $L=16$",
        transform=ax.transAxes,
        fontsize=12,
        verticalalignment="top",
        horizontalalignment="right",
    )

    # Legend positioned to avoid data
    ax.legend(
        loc="upper right",
        bbox_to_anchor=(0.95, 0.85),
        frameon=True,
        framealpha=0.9,
        edgecolor="black",
    )

    # Grid for readability (subtle)
    ax.grid(True, which="major", linestyle="-", linewidth=0.5, alpha=0.3)
    ax.grid(True, which="minor", linestyle=":", linewidth=0.3, alpha=0.2)

    # Ensure minor ticks are visible on log scale
    ax.yaxis.set_minor_locator(
        LogLocator(
            base=10.0, subs=(0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9), numticks=100
        )
    )

    # Tight layout
    plt.tight_layout()

    # Save figure
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_output_path = os.path.join(project_root, output_path)

    # Ensure output directory exists
    os.makedirs(os.path.dirname(full_output_path), exist_ok=True)

    plt.savefig(full_output_path)
    print(f"Figure saved to: {full_output_path}")

    # Also save as PNG for quick viewing
    png_path = full_output_path.replace(".pdf", ".png")
    plt.savefig(png_path)
    print(f"PNG saved to: {png_path}")

    plt.close()

    return fig


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("FIGURE 4 REPRODUCTION")
    print("Reference: White, Phys. Rev. B 48, 10345 (1993), Section VII")
    print("=" * 70)

    # Load computed data
    print("\nLoading data from data/fig4.csv...")
    df = load_fig4_data()
    print(f"Loaded {len(df)} data points")
    print("\nData:")
    print(df.to_string(index=False))

    # Create the plot
    print("\nGenerating Figure 4...")
    plot_fig4(df, output_path="plots/fig4_plot.pdf")

    print("\n" + "=" * 70)
    print("DONE")
    print("=" * 70)

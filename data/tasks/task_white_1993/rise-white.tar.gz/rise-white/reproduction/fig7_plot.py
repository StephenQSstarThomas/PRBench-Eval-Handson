"""
Figure 7 Reproduction: Local Observables for S=1 Chain

Reproduces Figure 7 from White, Phys. Rev. B 48, 10345 (1993), Section VII.

Figure Description (from paper):
    "Local bond strength (a) and local value of S_z (b) for a S=1 system
    with 60 sites. The S=1/2 effective spins on the ends are clearly
    visible in (b), which shows one of the low-lying triplet states
    just above the ground state."

Plot Specifications:
    Panel (a):
        - X-axis: i, linear scale, range 0 to 60
        - Y-axis: <S_i · S_{i+1}>, linear scale, range -1.7 to -1.2

    Panel (b):
        - X-axis: i, linear scale, range 0 to 60
        - Y-axis: <S_i^z>, linear scale, range -0.4 to 0.6
"""

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Use LaTeX-style fonts for publication quality
plt.rcParams.update(
    {
        "text.usetex": False,
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 12,
        "axes.labelsize": 14,
        "axes.titlesize": 14,
        "legend.fontsize": 11,
        "xtick.labelsize": 12,
        "ytick.labelsize": 12,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.linewidth": 1.0,
        "xtick.major.width": 1.0,
        "ytick.major.width": 1.0,
    }
)


def load_fig7_data(filepath="data/fig7.csv"):
    """Load computed local observable data from CSV."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_path = os.path.join(project_root, filepath)

    df = pd.read_csv(full_path)
    return df


def plot_fig7(df, output_path="data/fig7_plot.pdf"):
    """
    Create publication-quality reproduction of Figure 7.

    Two-panel figure showing local observables for S=1 chain.
    """
    fig, axes = plt.subplots(2, 1, figsize=(8, 8), sharex=True)

    # Extract data
    i = df["i"].values

    # Panel (a): Bond strength
    ax_a = axes[0]
    if "Bond Strength" in df.columns:
        bond_strength = df["Bond Strength"].values

        valid_mask = ~np.isnan(bond_strength)
        x = i[valid_mask]
        y = bond_strength[valid_mask]

        ax_a.plot(
            x,
            y,
            linestyle="-",
            linewidth=0.8,
            marker="o",
            markerfacecolor="black",
            markeredgecolor="black",
            markeredgewidth=0.5,
            markersize=3,
            color="black",
        )

    ax_a.set_xlim(0, 60)
    ax_a.set_ylim(-1.7, -1.2)
    ax_a.set_ylabel(r"$\langle S_i \cdot S_{i+1} \rangle$")

    ax_a.text(
        0.02,
        0.95,
        r"(a) $L=60$, $S=1$, Open BCs",
        transform=ax_a.transAxes,
        fontsize=11,
        verticalalignment="top",
        horizontalalignment="left",
    )

    ax_a.grid(True, which="major", linestyle="-", linewidth=0.5, alpha=0.3)

    # Panel (b): Local Sz
    ax_b = axes[1]
    if "Local Sz" in df.columns:
        local_Sz = df["Local Sz"].values

        valid_mask = ~np.isnan(local_Sz)
        x = i[valid_mask]
        y = local_Sz[valid_mask]

        ax_b.plot(
            x,
            y,
            linestyle="-",
            linewidth=0.8,
            marker="o",
            markerfacecolor="black",
            markeredgecolor="black",
            markeredgewidth=0.5,
            markersize=3,
            color="black",
        )

    ax_b.set_xlim(0, 60)
    ax_b.set_ylim(-0.4, 0.6)
    ax_b.set_xlabel(r"$i$")
    ax_b.set_ylabel(r"$\langle S_i^z \rangle$")

    ax_b.text(
        0.02,
        0.95,
        r"(b) $L=60$, $S=1$, Open BCs, $S_z^{tot}=1$",
        transform=ax_b.transAxes,
        fontsize=11,
        verticalalignment="top",
        horizontalalignment="left",
    )

    # Add horizontal line at y=0 for reference
    ax_b.axhline(y=0, color="gray", linestyle="--", linewidth=0.5, alpha=0.5)

    ax_b.grid(True, which="major", linestyle="-", linewidth=0.5, alpha=0.3)

    # Tight layout
    plt.tight_layout()

    # Save figure
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_output_path = os.path.join(project_root, output_path)

    os.makedirs(os.path.dirname(full_output_path), exist_ok=True)

    plt.savefig(full_output_path)
    print(f"Figure saved to: {full_output_path}")

    png_path = full_output_path.replace(".pdf", ".png")
    plt.savefig(png_path)
    print(f"PNG saved to: {png_path}")

    plt.close()

    return fig


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("FIGURE 7 REPRODUCTION")
    print("Reference: White, Phys. Rev. B 48, 10345 (1993), Section VII")
    print("=" * 70)

    # Load computed data
    print("\nLoading data from data/fig7.csv...")
    df = load_fig7_data()
    print(f"Loaded {len(df)} data points")

    # Create the plot
    print("\nGenerating Figure 7...")
    plot_fig7(df, output_path="plots/fig7_plot.pdf")

    print("\n" + "=" * 70)
    print("DONE")
    print("=" * 70)

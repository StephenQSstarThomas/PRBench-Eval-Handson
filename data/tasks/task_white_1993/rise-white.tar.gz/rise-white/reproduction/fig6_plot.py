"""
Figure 6 Reproduction: Local Bond Strength for S=1/2 Chains

Reproduces Figure 6 from White, Phys. Rev. B 48, 10345 (1993), Section VII.

Figure Description (from paper):
    "Local bond strength for (a) 60 site and (b) 61 site S=1/2 chains with
    open boundary conditions."

Plot Specifications:
    - X-axis: i (bond index, 1-indexed), linear scale
    - Y-axis: <S_i · S_{i+1}> (bond strength), linear scale, range -0.7 to -0.2
    - For L sites, bonds run from i=1 to i=L-1

Panels:
    (a) L=60 - bond-strength alternation pattern
    (b) L=61 - domain wall due to frustration
    (c) L=60, J_edge=0.236 - soft BCs reduce alternation
"""

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Use LaTeX-style fonts for publication quality
plt.rcParams.update(
    {
        "text.usetex": False,
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 12,
        "axes.labelsize": 14,
        "axes.titlesize": 14,
        "legend.fontsize": 11,
        "xtick.labelsize": 12,
        "ytick.labelsize": 12,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.linewidth": 1.0,
        "xtick.major.width": 1.0,
        "ytick.major.width": 1.0,
    }
)


def load_fig6_data(filepath="data/fig6.csv"):
    """Load computed bond strength data from CSV."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_path = os.path.join(project_root, filepath)

    df = pd.read_csv(full_path)
    return df


def plot_fig6(df, output_path="data/fig6_plot.pdf"):
    """
    Create publication-quality reproduction of Figure 6.

    Three-panel figure showing bond strength for S=1/2 chains.
    """
    fig, axes = plt.subplots(3, 1, figsize=(8, 10), sharex=True)

    # Extract data
    i = df["i"].values

    # Panel configurations
    panels = [
        {
            "ax": axes[0],
            "key": "Panel (a)",
            "title": r"(a) $L=60$, $S=1/2$, Open BCs",
            "L": 60,
        },
        {
            "ax": axes[1],
            "key": "Panel (b)",
            "title": r"(b) $L=61$, $S=1/2$, Open BCs",
            "L": 61,
        },
        {
            "ax": axes[2],
            "key": "Panel (c)",
            "title": r"(c) $L=60$, $S=1/2$, Open BCs, $J_{edge}=0.236$",
            "L": 60,
        },
    ]

    for panel in panels:
        ax = panel["ax"]
        key = panel["key"]

        if key not in df.columns:
            continue

        bond_strength = df[key].values

        # Filter valid data
        valid_mask = ~np.isnan(bond_strength)

        x = i[valid_mask]
        y = bond_strength[valid_mask]

        # Plot with filled circles and line
        ax.plot(
            x,
            y,
            linestyle="-",
            linewidth=0.8,
            marker="o",
            markerfacecolor="black",
            markeredgecolor="black",
            markeredgewidth=0.5,
            markersize=3,
            color="black",
        )

        # Set axis limits
        ax.set_xlim(0, panel["L"])
        ax.set_ylim(-0.7, -0.2)

        # Labels
        ax.set_ylabel(r"$\langle S_i \cdot S_{i+1} \rangle$")

        # Title/annotation
        ax.text(
            0.02,
            0.95,
            panel["title"],
            transform=ax.transAxes,
            fontsize=11,
            verticalalignment="top",
            horizontalalignment="left",
        )

        # Grid
        ax.grid(True, which="major", linestyle="-", linewidth=0.5, alpha=0.3)

    # X-axis label only on bottom panel
    axes[2].set_xlabel(r"$i$")

    # Tight layout
    plt.tight_layout()

    # Save figure
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_output_path = os.path.join(project_root, output_path)

    os.makedirs(os.path.dirname(full_output_path), exist_ok=True)

    plt.savefig(full_output_path)
    print(f"Figure saved to: {full_output_path}")

    png_path = full_output_path.replace(".pdf", ".png")
    plt.savefig(png_path)
    print(f"PNG saved to: {png_path}")

    plt.close()

    return fig


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("FIGURE 6 REPRODUCTION")
    print("Reference: White, Phys. Rev. B 48, 10345 (1993), Section VII")
    print("=" * 70)

    # Load computed data
    print("\nLoading data from data/fig6.csv...")
    df = load_fig6_data()
    print(f"Loaded {len(df)} data points")

    # Create the plot
    print("\nGenerating Figure 6...")
    plot_fig6(df, output_path="plots/fig6_plot.pdf")

    print("\n" + "=" * 70)
    print("DONE")
    print("=" * 70)

"""
Figure 5 Reproduction: Energy Gap vs Inverse Chain Length

Reproduces Figure 5 from White, Phys. Rev. B 48, 10345 (1993), Section VII.

Figure Description (from paper):
    "Gaps Δ_L between the ground and first excited states for S=1/2 and S=1
    systems with periodic boundary conditions versus the inverse length of
    the chain 1/L."

Plot Specifications:
    - X-axis: 1/L (inverse chain length), linear scale, range 0.00 to 0.10
    - Y-axis: Δ_L (energy gap), linear scale, range 0.0 to 0.5
    - Boundary conditions: Periodic

Data Series (2 curves with markers from paper):
    - S=1:   open circles (○), solid line - gap extrapolates to ~0.411
    - S=1/2: filled circles (●), solid line - gap extrapolates to 0
"""

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Use LaTeX-style fonts for publication quality
plt.rcParams.update(
    {
        "text.usetex": False,  # Set True if LaTeX is available
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 12,
        "axes.labelsize": 14,
        "axes.titlesize": 14,
        "legend.fontsize": 11,
        "xtick.labelsize": 12,
        "ytick.labelsize": 12,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.linewidth": 1.0,
        "xtick.major.width": 1.0,
        "ytick.major.width": 1.0,
    }
)


def load_fig5_data(filepath="data/fig5.csv"):
    """Load computed energy gap data from CSV."""
    # Resolve path relative to project root
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_path = os.path.join(project_root, filepath)

    df = pd.read_csv(full_path)
    return df


def plot_fig5(df, output_path="data/fig5_plot.pdf"):
    """
    Create publication-quality reproduction of Figure 5.

    Follows exact specifications from the paper:
    - Linear y-axis from 0.0 to 0.5
    - Linear x-axis from 0.00 to 0.10
    - Specific marker styles for each curve:
      - S=1: open circles
      - S=1/2: filled circles
    """
    fig, ax = plt.subplots(figsize=(8, 6))

    # Extract data columns
    inv_L = df["1/L"].values
    gap_s1 = df["Gap S=1"].values
    gap_s12 = df["Gap S=1/2"].values

    # Filter to x-axis range (0 to 0.10)
    mask = inv_L <= 0.10

    # Define plot styles matching the paper exactly
    # Paper specifies:
    #   - S=1:   open circles
    #   - S=1/2: filled circles

    # Plot S=1 (open circles) - gap extrapolates to ~0.411 (Haldane gap)
    valid_s1 = mask & ~np.isnan(gap_s1)
    ax.plot(
        inv_L[valid_s1],
        gap_s1[valid_s1],
        linestyle="-",
        linewidth=0.8,
        marker="o",
        markerfacecolor="none",
        markeredgecolor="black",
        markeredgewidth=0.8,
        markersize=6,
        color="black",
        label=r"$S=1$",
    )

    # Plot S=1/2 (filled circles) - gap extrapolates to 0
    valid_s12 = mask & ~np.isnan(gap_s12)
    ax.plot(
        inv_L[valid_s12],
        gap_s12[valid_s12],
        linestyle="-",
        linewidth=0.8,
        marker="o",
        markerfacecolor="black",
        markeredgecolor="black",
        markeredgewidth=0.5,
        markersize=5,
        color="black",
        label=r"$S=1/2$",
    )

    # Set axis limits matching the paper
    ax.set_xlim(0.00, 0.10)
    ax.set_ylim(0.0, 0.5)

    # Axis labels with LaTeX formatting
    ax.set_xlabel(r"$1/L$")
    ax.set_ylabel(r"$\Delta_L$")

    # Legend positioned to avoid data
    ax.legend(
        loc="upper right",
        bbox_to_anchor=(0.95, 0.95),
        frameon=True,
        framealpha=0.9,
        edgecolor="black",
    )

    # Grid for readability (subtle)
    ax.grid(True, which="major", linestyle="-", linewidth=0.5, alpha=0.3)

    # Tight layout
    plt.tight_layout()

    # Save figure
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_output_path = os.path.join(project_root, output_path)

    # Ensure output directory exists
    os.makedirs(os.path.dirname(full_output_path), exist_ok=True)

    plt.savefig(full_output_path)
    print(f"Figure saved to: {full_output_path}")

    # Also save as PNG for quick viewing
    png_path = full_output_path.replace(".pdf", ".png")
    plt.savefig(png_path)
    print(f"PNG saved to: {png_path}")

    plt.close()

    return fig


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("FIGURE 5 REPRODUCTION")
    print("Reference: White, Phys. Rev. B 48, 10345 (1993), Section VII")
    print("=" * 70)

    # Load computed data
    print("\nLoading data from data/fig5.csv...")
    df = load_fig5_data()
    print(f"Loaded {len(df)} data points")
    print("\nData:")
    print(df.to_string(index=False))

    # Create the plot
    print("\nGenerating Figure 5...")
    plot_fig5(df, output_path="plots/fig5_plot.pdf")

    print("\n" + "=" * 70)
    print("DONE")
    print("=" * 70)

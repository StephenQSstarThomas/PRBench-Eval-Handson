"""
Figure 8 Reproduction: Density-Matrix Eigenvalues vs Target States

Reproduces Figure 8 from White, Phys. Rev. B 48, 10345 (1993), Section VII.

Figure Description (from paper):
    "Density-matrix eigenvalues w_alpha vs alpha for a 32 site S=1/2 system
    with open boundary conditions, with various numbers of target states."

Plot Specifications:
    - X-axis: alpha (eigenvalue index), linear scale, range 0 to 50
    - Y-axis: w_alpha (density-matrix eigenvalues), log scale, 10^0 to 10^-8
    - System: L=32 sites, S=1/2, Open BCs

Data Series (5 curves with markers from paper):
    - 1 Target State:  open squares (□), solid line
    - 2 Target States: open circles (○), solid line
    - 3 Target States: open triangles (△), solid line
    - 4 Target States: filled squares (■), solid line
    - 5 Target States: filled circles (●), solid line

Annotations:
    - "S=1/2, L=32" in top right corner
"""

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.ticker import LogLocator

# Use LaTeX-style fonts for publication quality
plt.rcParams.update(
    {
        "text.usetex": False,  # Set True if LaTeX is available
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 12,
        "axes.labelsize": 14,
        "axes.titlesize": 14,
        "legend.fontsize": 10,
        "xtick.labelsize": 12,
        "ytick.labelsize": 12,
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.linewidth": 1.0,
        "xtick.major.width": 1.0,
        "ytick.major.width": 1.0,
    }
)


def load_fig8_data(filepath="data/fig8.csv"):
    """Load computed density-matrix eigenvalues from CSV."""
    # Resolve path relative to project root
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_path = os.path.join(project_root, filepath)

    df = pd.read_csv(full_path)
    return df


def plot_fig8(df, output_path="data/fig8_plot.pdf"):
    """
    Create publication-quality reproduction of Figure 8.

    Follows exact specifications from the paper:
    - Logarithmic y-axis from 10^0 to 10^-8
    - Linear x-axis from 0 to 50
    - Specific marker styles for each target state count
    """
    fig, ax = plt.subplots(figsize=(8, 6))

    # Extract data columns
    alpha = df["alpha"].values

    # Define plot styles matching the paper exactly
    # Paper specifies:
    #   - 1 Target:  open squares
    #   - 2 Targets: open circles
    #   - 3 Targets: open triangles
    #   - 4 Targets: filled squares
    #   - 5 Targets: filled circles

    plot_configs = [
        {
            "key": "1 Target",
            "label": r"1 Target",
            "marker": "s",
            "markerfacecolor": "none",
            "markeredgecolor": "black",
            "markeredgewidth": 0.8,
            "markersize": 6,
        },
        {
            "key": "2 Targets",
            "label": r"2 Targets",
            "marker": "o",
            "markerfacecolor": "none",
            "markeredgecolor": "black",
            "markeredgewidth": 0.8,
            "markersize": 6,
        },
        {
            "key": "3 Targets",
            "label": r"3 Targets",
            "marker": "^",
            "markerfacecolor": "none",
            "markeredgecolor": "black",
            "markeredgewidth": 0.8,
            "markersize": 6,
        },
        {
            "key": "4 Targets",
            "label": r"4 Targets",
            "marker": "s",
            "markerfacecolor": "black",
            "markeredgecolor": "black",
            "markeredgewidth": 0.5,
            "markersize": 5,
        },
        {
            "key": "5 Targets",
            "label": r"5 Targets",
            "marker": "o",
            "markerfacecolor": "black",
            "markeredgecolor": "black",
            "markeredgewidth": 0.5,
            "markersize": 5,
        },
    ]

    # Plot each curve
    for config in plot_configs:
        key = config["key"]
        if key not in df.columns:
            continue

        w_alpha = df[key].values

        # Filter out NaN values and clip to x-axis range
        valid_mask = ~np.isnan(w_alpha) & (alpha <= 50)
        x = alpha[valid_mask]
        y = w_alpha[valid_mask]

        # Filter out zero or negative values for log scale
        positive_mask = y > 0
        x = x[positive_mask]
        y = y[positive_mask]

        ax.semilogy(
            x,
            y,
            linestyle="-",
            linewidth=0.8,
            marker=config["marker"],
            markerfacecolor=config["markerfacecolor"],
            markeredgecolor=config["markeredgecolor"],
            markeredgewidth=config["markeredgewidth"],
            markersize=config["markersize"],
            color="black",
            label=config["label"],
        )

    # Set axis limits matching the paper
    ax.set_xlim(0, 50)
    ax.set_ylim(1e-8, 1e0)

    # Axis labels with LaTeX formatting
    ax.set_xlabel(r"$\alpha$")
    ax.set_ylabel(r"$w_\alpha$")

    # Add "S=1/2, L=32" annotation in top right corner (paper style)
    ax.text(
        0.95,
        0.95,
        r"$S=1/2$, $L=32$",
        transform=ax.transAxes,
        fontsize=12,
        verticalalignment="top",
        horizontalalignment="right",
    )

    # Legend positioned to avoid data
    ax.legend(
        loc="upper right",
        bbox_to_anchor=(0.95, 0.85),
        frameon=True,
        framealpha=0.9,
        edgecolor="black",
    )

    # Grid for readability (subtle)
    ax.grid(True, which="major", linestyle="-", linewidth=0.5, alpha=0.3)
    ax.grid(True, which="minor", linestyle=":", linewidth=0.3, alpha=0.2)

    # Ensure minor ticks are visible on log scale
    ax.yaxis.set_minor_locator(
        LogLocator(
            base=10.0, subs=(0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9), numticks=100
        )
    )

    # Tight layout
    plt.tight_layout()

    # Save figure
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    full_output_path = os.path.join(project_root, output_path)

    # Ensure output directory exists
    os.makedirs(os.path.dirname(full_output_path), exist_ok=True)

    plt.savefig(full_output_path)
    print(f"Figure saved to: {full_output_path}")

    # Also save as PNG for quick viewing
    png_path = full_output_path.replace(".pdf", ".png")
    plt.savefig(png_path)
    print(f"PNG saved to: {png_path}")

    plt.close()

    return fig


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("FIGURE 8 REPRODUCTION")
    print("Reference: White, Phys. Rev. B 48, 10345 (1993), Section VII")
    print("=" * 70)

    # Load computed data
    print("\nLoading data from data/fig8.csv...")
    df = load_fig8_data()
    print(f"Loaded {len(df)} data points")
    print("\nData (first 10 rows):")
    print(df.head(10).to_string(index=False))

    # Create the plot
    print("\nGenerating Figure 8...")
    plot_fig8(df, output_path="plots/fig8_plot.pdf")

    print("\n" + "=" * 70)
    print("DONE")
    print("=" * 70)
